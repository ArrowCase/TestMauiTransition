﻿namespace TestMauiTransition
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void OnButtonClicked(object sender, EventArgs e)
        {
            App.Current?.MainPage?.Navigation?.PushAsync(new SecondPage(), animated: false);
        }
    }
}
